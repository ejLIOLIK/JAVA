package Util;

public class Command {

	public static void pr(String str) {
		System.out.print(str);
	}
}
