package Display;

import Post.Post;

public class Display {

	public static void mainDisp() {
		lineD();
		System.out.println("게시판 입니다.");
		lineD();
		menuDisp();
		lineS();
	}
	
	static void menuDisp() {
		System.out.println("1.리스트/2.읽기/3.쓰기/4.수정/5.삭제/6.나가기");
	}
	
	static void lineD() {
		System.out.println("====================================");
	}
	
	public static void lineS() {
		System.out.println("------------------------------------");
	}
	
	public static void ErMsg() {
		System.out.println("잘못된 입력입니다.");
	}

	public static void readPost(Post p) {
		lineS();
		System.out.println("글 제목 : " + p.title + "	작성자 :" + p.writer);
		System.out.println("글 번호 : " + p.instanceNo + "	조회수 :" + p.hit);
		System.out.println("글 내용");
		System.out.println(p.content);
		System.out.println("작성일 : " + p.date);
		lineS();
	}
}
