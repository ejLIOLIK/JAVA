package Post;

import java.time.LocalDate;

import Proc.Setting;

public class Post {

//	static public int no = 0; // 글 번호 관리

	public int instanceNo = 0;
	public String title;
	public String content;
	public String writer;
	public int hit;
	public String date;

	public Post(String title, String content, String writer) {

		instanceNo = Setting.no; // 1번부터 ~
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.hit = 0;
		LocalDate now = LocalDate.now();
		date = now.toString();
	}
}
