package Util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Util {
	
	static Scanner sc = new Scanner(System.in);
	static BufferedReader rd = new BufferedReader(new InputStreamReader(System.in));


	static public String read(String comment) {
		System.out.print(comment+" :");
		return sc.next();
	}
	
	static public String readLong(String comment) {
		System.out.print(comment+" :");
		try {
			return rd.readLine();
		} catch (IOException e) { // 예외처리
			e.printStackTrace();
			return null;
		}
	}
	
}
