package Proc;

import java.util.ArrayList;

import Post.Post;

public class Setting {
	
	public static ArrayList<Post> posts;
	public static int no;
	
	static void settingBoard(){
		no = 0; // 글 번호 관리
		posts = new ArrayList<>();
	}
	
}
