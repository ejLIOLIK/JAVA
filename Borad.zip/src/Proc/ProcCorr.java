package Proc;

import Display.Display;
import Post.Post;
import Util.Util;

public class ProcCorr {
	
	static void run() {
		
		String cmd = Util.read("수정할 글 번호");

		for(Post p: Setting.posts) {
			if(cmd.equals(p.instanceNo+"")){
				Display.readPost(p);
			}			
		}
		
		String cmd2 = Util.read("1.글제목/2.글내용/3.작성자");
		String TempCor = "";

		switch (cmd2) {
		case "1":
			while (true) {
				TempCor = Util.readLong("글제목");
				if (TempCor.length() > 0) {
					for (Post p : Setting.posts) {
						if (cmd.equals(p.instanceNo + "")) {
							p.title = TempCor;
						}
					}
					System.out.println("글 제목이 수정되었습니다.");
					break;
				} else {
					 Display.ErMsg();
				}
			}
			break;
		case "2":
			while (true) {
				TempCor = Util.readLong("글내용");
				if (TempCor.length() > 0) {
					for (Post p : Setting.posts) {
						if (cmd.equals(p.instanceNo + "")) {
							p.content = TempCor;
						}
					}
					System.out.println("글 내용이 수정되었습니다.");
					break;
				} else {
					 Display.ErMsg();
				}
			}
			break;
		case "3":
			while (true) {
				TempCor = Util.readLong("작성자");
				if (TempCor.length() > 0) {
					for (Post p : Setting.posts) {
						if (cmd.equals(p.instanceNo + "")) {
							p.writer = TempCor;
						}
					}
					System.out.println("작성자가 수정되었습니다.");
					break;
				} else {
					 Display.ErMsg();
				}
			}
			break;
		default:
			 Display.ErMsg();
		}
		
	}

}
