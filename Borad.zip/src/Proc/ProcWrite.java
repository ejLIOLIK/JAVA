package Proc;

import Display.Display;
import Post.Post;
import Util.Util;

public class ProcWrite {

	static void run() {
		
		String str_t="";
		String str_c="";
		String str_w="";
		
		System.out.println("게시글을 작성합니다.");

		while (true) {
			str_w = Util.readLong("작성자");
			if (str_w.length() > 0) {
				break;
			}
			else {
				Display.ErMsg();
			}
		}

		while (true) {
			str_t = Util.readLong("글 제목");
			if (str_t.length() > 0) {
				break;
			}
			else {
				Display.ErMsg();
			}
		}

		while (true) {
			str_c = Util.readLong("글 내용");
			if (str_c.length() > 0) {
				break;
			}
			else {
				Display.ErMsg();
			}
		}

		Setting.no += 1;
		Post tmp = new Post(str_t, str_c, str_w);
		Setting.posts.add(tmp);
		System.out.println("게시글이 작성되었습니다.");
	}
}
