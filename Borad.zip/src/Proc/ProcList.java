package Proc;

import Display.Display;
import Post.Post;

public class ProcList {

	static void run() {
		
		System.out.println("글번호" + "	글제목	" + "작성자	" + "조회수" + "	작성일" );
		Display.lineS();
		for(Post p : Setting.posts) {
			System.out.println(p.instanceNo +"	"+ p.title + "	" + p.writer +"	"+ p.hit + " " + p.date);
		}
		Display.lineS();
	}
}
