package Proc;

import Display.Display;
import Util.Util;

public class Board {
	void run() {
		
		Setting.settingBoard();
		Display.mainDisp();
		
		String key="";
		
		loop_quit : while(true) {
			
			key = Util.read("입력");
			
			switch(key) {
			case "1":
				ProcList.run();
				break;
			case "2":
				ProcRead.run();
				break;
			case "3":
				ProcWrite.run();
				break;
			case "4":
				ProcCorr.run();
				break;
			case "5":
				ProcDel.run();
				break;
			case "6":
				System.out.println("종료됩니다.");
				break loop_quit;
			}
		}
		
	}
}
