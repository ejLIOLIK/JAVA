package Proc;

import Display.Display;
import Post.Post;
import Util.Util;

public class ProcDel {
	
	static void run() {
		
		String strNo;
		
		System.out.println("게시글을 지웁니다.");

		while (true) {
			strNo = Util.read("게시글 번호");
			if (strNo.length() > 0) {
				break;
			}
			else {
				Display.ErMsg();
			}
		}
		
		for(Post p:Setting.posts) {
			if(strNo.equals(p.instanceNo+"")) {
				Setting.posts.remove(p);
				break;
			}
		}
		
	}

}
