package Proc;

import Display.Display;
import Post.Post;
import Util.Util;

public class ProcRead {

	static void run() {
		
		String strNo;
		
		System.out.println("게시글을 읽습니다.");

		while (true) {
			strNo = Util.read("게시글 번호");
			if (strNo.length() > 0) {
				break;
			}
			else {
				Display.ErMsg();
			}
		}
		
		for(Post p:Setting.posts) {
			if(strNo.equals(p.instanceNo+"")) {
				Display.readPost(p);
				p.hit++; // 조회수
				break;
			}
		}
		
	}
	
}
