/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module Kiosk2 {
}