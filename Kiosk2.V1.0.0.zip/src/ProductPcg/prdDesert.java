package ProductPcg;

public class prdDesert extends Product {

	public prdDesert(String name, int price) {
		super(name, price);
	}

}
