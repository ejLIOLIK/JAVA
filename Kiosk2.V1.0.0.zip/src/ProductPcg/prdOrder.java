package ProductPcg;

public class prdOrder {

	public Product p;
	public int amount;

}
