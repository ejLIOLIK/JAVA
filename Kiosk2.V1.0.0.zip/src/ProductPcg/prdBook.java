package ProductPcg;

public class prdBook extends Product {

	public prdBook(String name, int price) {
		super(name, price);
	}

}
