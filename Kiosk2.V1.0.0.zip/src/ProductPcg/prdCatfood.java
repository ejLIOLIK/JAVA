package ProductPcg;

public class prdCatfood extends Product {

	public prdCatfood(String name, int price) {
		super(name, price);
	}

}
