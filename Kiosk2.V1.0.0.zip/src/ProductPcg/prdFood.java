package ProductPcg;

public class prdFood extends Product {

	public prdFood(String name, int price) {
		super(name, price);
	}

}

