package Util;

import java.util.ArrayList;

import kiosk.catcafe.KioskObj;
import kiosk.catcafe.Product;

public class DP {
	
	final static String DOT = "=";
	final static int DOT_COUNT = 40;
	
	public static void line() {
		
		Command.Wn("");
		for(int i=0;i<DOT_COUNT;i++) {
			Command.pr(DOT);
		}
		Command.Wn("");
	}
	
	public static void title() {
		line();
		Command.pr(" *** Cat Cafe Kiosk ***");
		line();
	}
	
	// 메뉴판 출력
	public static void menuPrint(String str, ArrayList<Product> p) {

		Command.Wn("* "+str+" *");
		for(Product tmp :p) {
			tmp.info();
		}
	}
	
	// 메뉴판 전체 출력
	public static void menuPrintAll() {
		menuPrint("식사", KioskObj.food); 
		menuPrint("음료", KioskObj.drink);
		menuPrint("디저트", KioskObj.desert);
		menuPrint("고양이간식", KioskObj.catfood);
		menuPrint("책 대여", KioskObj.book);
	}
}
