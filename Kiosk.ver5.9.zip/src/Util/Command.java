package Util;

public class Command {

	public static void pr(String str) {
		System.out.print(str);
	}
	
	public static void Wn(String str) {
		System.out.println(str);
	}
}
