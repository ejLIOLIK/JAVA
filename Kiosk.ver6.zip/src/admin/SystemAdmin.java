package admin;

import java.util.ArrayList;

import Util.Command;
import Util.DP;
import kiosk.catcafe.Kiosk;
import kiosk.catcafe.KioskObj;
import kiosk.catcafe.Product;

public class SystemAdmin {
	
	Product tmp;
	String nameTmp="";
	int priceTmp;
	int menuTmp;

	public void run() { //

//		z	등록
//		x	삭제
//		c	수정
//		v	리스트
		loop_admin: while (true) {
			Command.Wn("admin system : o주문관리 z상품관리 q종료");
			KioskObj.cmd = KioskObj.sc.next();
			
			loop_q: switch(KioskObj.cmd) {
			case "o":
				while (true) {
					Command.Wn("주문관리");
					Command.Wn("admin system : o주문 v주문서조회 q종료");
					KioskObj.cmd = KioskObj.sc.next();

					switch (KioskObj.cmd) {
					case "o":
						Kiosk.procOlder();
						break;
					case "v":
						printOrderList();
						break;
					case "q":
						break loop_q;
					default:
					}
				}
		
			case "z":
				while (true) {
					
					Command.Wn("상품관리");
					Command.Wn("admin system : z등록 x삭제 v리스트 q종료"); //c수정 
					KioskObj.cmd = KioskObj.sc.next();
					
					switch (KioskObj.cmd) {
					case "z":
						
						Command.Wn("메뉴를 등록합니다.");
						Command.Wn("분류를 선택하세요. 1식사 2음료 3디저트 4고양이간식 5책 대여");
						menuTmp = KioskObj.sc.nextInt();

						Command.Wn("메뉴 이름을 입력하세요.");
						nameTmp = KioskObj.sc.next();
						
						Command.Wn("금액을 입력하세요.");
						priceTmp = KioskObj.sc.nextInt();
						
						switch(menuTmp) {
						case 1:
							KioskObj.food.add(new Product(nameTmp,priceTmp));
							break;
						case 2:
							KioskObj.drink.add(new Product(nameTmp,priceTmp));
							break;
						case 3:
							KioskObj.desert.add(new Product(nameTmp,priceTmp));
							break;
						case 4:
							KioskObj.catfood.add(new Product(nameTmp,priceTmp));
							break;
						case 5:
							KioskObj.book.add(new Product(nameTmp,priceTmp));
							break;
							default:
						}
						
						break;
					case "x": //x	삭제
						//Command.Wn("x 입력 확인 : 미구현");
						
						Command.Wn("메뉴를 삭제합니다.");
						Command.Wn("분류를 선택하세요. 1식사 2음료 3디저트 4고양이간식 5책 대여");
						menuTmp = KioskObj.sc.nextInt();

						Command.Wn("메뉴 이름을 입력하세요.");
						nameTmp = KioskObj.sc.next();
						
						switch(menuTmp) {
						case 1:
							KioskObj.food.remove(searchNameList(KioskObj.food,nameTmp));
							break;
						case 2:
							KioskObj.drink.remove(searchNameList(KioskObj.drink,nameTmp));
							break;
						case 3:
							KioskObj.desert.remove(searchNameList(KioskObj.desert,nameTmp));
							break;
						case 4:
							KioskObj.catfood.remove(searchNameList(KioskObj.catfood,nameTmp));
							break;
						case 5:
							KioskObj.book.remove(searchNameList(KioskObj.book,nameTmp));
							break;
							default:
						}
						break;
					case "c": //c	수정
						Command.Wn("c 입력 확인 : 미구현");
						break;
					case "v": // 제품 리스트
						DP.menuPrintAllAdmin();
						break;
					case "q":
						Command.Wn("q 입력 확인");
						break loop_q;
					default:
					}
				}
			case "q":
				break loop_admin;
			}
		}
	}
	
	void printOrderList() {
		
		for(int i = 0;i<KioskObj.orderlist.size();i++) {
			
			Command.Wn("");
			Command.Wn("주문서 번호 : " +(i+1));
			Command.Wn(KioskObj.orderlist.get(i));
		}
		Command.Wn("");
	}
	
	int searchNameList(ArrayList<Product> p, String str) {
	
		for(int i=0;i<p.size();i++) {
			if(p.get(i).name.equals(str)) {
				return i;
			}
		}
		
		Command.Wn("Error : 찾을 수 없습니다");
		return -1;
	}

}
