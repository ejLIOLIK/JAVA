package kiosk.catcafe;
import java.util.ArrayList;

import Util.Command;
import Util.DP;
import admin.SystemAdmin;

public class Kiosk {
	
	static procMenu menu = new procMenu(); // 메뉴 선택 받는 프로세스
	static SystemAdmin SysAd = new SystemAdmin();

	void run() {

		KioskObj.productInit(); // 상품 리스트 등록

		while (true) {
			
			procOlder();

			Command.Wn("종료하시겠습니까? y / anykey");
			KioskObj.cmd = KioskObj.sc.next();

			if (KioskObj.cmd.equals("y")) {
				KioskObj.sc.close();
				break;
			}
		}
	}
	
	public static void procOlder() {
		
		DP.title();
		DP.menuPrintAll();
		DP.line();

		loop_a: while (true) { // 주문 받는 루프

			Command.Wn("");
			Command.Wn("[1.식사 / 2.음료 / 3.디저트 / 4.고양이간식 / 5.책 대여]");
			Command.Wn("[x.주문완료 / c.주문취소 / v.장바구니]");

			KioskObj.cmd = KioskObj.sc.next(); // 키 입력

			switch (KioskObj.cmd) {
			case "1":
				Command.Wn("[ 식사 ]");
				menu.Run(KioskObj.food);
				break;
			case "2":
				Command.Wn("[ 음료 ]");
				menu.Run(KioskObj.drink);
				break;
			case "3":
				Command.Wn("[ 디저트 ]");
				menu.Run(KioskObj.desert);
				break;
			case "4":
				Command.Wn("[ 고양이간식 ]");
				menu.Run(KioskObj.catfood);
				break;
			case "5":
				Command.Wn("[ 책 대여 ]");
				menu.Run(KioskObj.book);
				break;
			case "c":
				KioskObj.basket.clear();
				Command.Wn("주문이 취소됩니다.");
				DP.line();
				break;
			case "x": // 주문 완료
				break loop_a;
			case "v": // 장바구니 출력
				cartList(KioskObj.basket);
				break;
			case "admin": // 관리자모드
				SysAd.run();
				break;
			default:
			}
		}

		orderList(KioskObj.basket);
		Command.Wn("주문이 완료되었습니다.");
	}

	//str의 제품이 CountArray에 총 몇 개 있는지 출력
	static void findPro(ArrayList<Product> p, String str) {
		for(Product tmp:p) {
			if(tmp.name.equals(str)) { //이용자가 입력한 제품명을 상품 리스트에서 찾아냄
				KioskObj.basket.add(tmp); // 장바구니 리스트에 해당 상품 추가
				System.out.println(tmp.name + " 선택 (총 " + CountArray(KioskObj.basket, str) + "개)");
			}
		}
	}

	//주문 완료
	static void orderList(ArrayList<Product> basket) {
		
		String orderStr = "";
		
		orderStr = cartList(basket);
		KioskObj.orderlist.add(orderStr);
		basket.clear();
		
	}

	//장바구니 조회
	static String cartList(ArrayList<Product> basket) {

		int sum = 0;
		String orderStr = "";

		ArrayList<String> str = new ArrayList<>(); //주문된 제품명만 입력
		boolean strTF = true; //이미 출력한 제품명인지 
		int count; //수량 저장

		DP.line();
		Command.Wn("주문 내역 : ");

		for (Product bas : basket) {
			for (String s : str) {
				if (bas.name.equals(s)) {
					strTF = false;
					break;
				}
			}

			if (strTF) {
				count = CountArray(basket, bas.name); //주문 수량 확인

				sum = sum + bas.price * count; // 합계 계산

				orderStr = orderStr+ bas.name + "(" + bas.price + "원) " + count + "개 / 총액 : " + count * bas.price + "원\n";
				str.add(bas.name);
			} 
			else {
				strTF = true;
			}
		}
		
		orderStr = orderStr+"\n ** 합계 : " + sum + "원";
		Command.pr(orderStr);
		DP.line();
		
		return orderStr;
	}

	// str 상품이 장바구니에 든 수량을 리턴
	static int CountArray(ArrayList<Product> basket, String str) {
		
		int order = 0;
		for(Product bas:basket) {
			if(bas.name.equals(str)) {
				order++;
			}
		}
		
		return order;
	}
}
