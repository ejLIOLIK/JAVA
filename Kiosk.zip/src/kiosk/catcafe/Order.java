package kiosk.catcafe;


// 아직 사용 XXXXX
public class Order {

	Product p;
	int option;
	int optPrice;
	
	Order(int opt, int price){
		option = opt;
		optPrice = price;
	}
	
}
