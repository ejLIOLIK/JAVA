package kiosk.catcafe;

public class Main {
	
	public static void main(String[] args) {
	
		Kiosk catcafe = new Kiosk();
		catcafe.run();
		
	}
}

