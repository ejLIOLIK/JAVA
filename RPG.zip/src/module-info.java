/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module RPG {
}